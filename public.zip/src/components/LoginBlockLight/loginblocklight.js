/**
 * Created by Paul on 22.01.2019.
 */
import React, { Component } from 'react';
import './loginblocklight.css'
// import { userLoggedIn } from '../../actions/userAuthActions'

export default class LoginBlockLight extends Component {

    userLogin=()=> {
        // console.log("LoginBlockLight.userLogin", this.inputEmail.value, this.inputPwd.value)
        this.props.onclick(this.inputEmail.value, this.inputPwd.value)
        this.props.firehide(true)
        // this.props.hidesteps();
    }
    userCancel=()=> {
        // console.log(this.inputEmail.value, this.inputPwd.value)
        // this.props.onclick(this.inputEmail.value, this.inputPwd.value)
        this.props.firehide(true)
    }
    componentDidMount() {
        this.inputEmail.focus();
    }
    // userLogout() {
    //
    // }
    render(){
            return (
                <div className="loginBlockLight">
                    <form>
                    <label>Email</label><input type="email" ref={input=>{this.inputEmail=input}}></input>
                    <label>Пароль</label><input type="password" ref={input=>{this.inputPwd=input}}></input>
                    <button type="submit" onClick={this.userLogin.bind(this)}>Войти</button><button onClick={this.userCancel.bind(this)}>Отмена</button>
                    </form>
                </div>
            )

    }
}