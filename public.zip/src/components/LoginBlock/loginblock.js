/**
 * Created by Paul on 22.01.2019.
 */
import React, { Component } from 'react';
import { connect } from 'react-redux'
import './loginblock.css'
import {numberToLang} from '../../components/helpers'
// import axios from 'axios';
import { FACEBOOK_URL, CREATEUSER_URL, UPDATESETUP_URL, SUBJECTS_GET_URL, STUDENTS_GET_URL, instanceAxios } from '../../config/URLs'
import emailPropType from 'email-prop-type';

class LoginBlock extends Component {

    constructor(props){
        super(props);
        this.state = ({ newUser : 0,
                        newEmail : "",
                        Error : "",})
    }
    createUser(){
        console.log(this.inputEmail.value.toString().split("@")[0], this.inputEmail.value, this.inputPwd.value)

        let name = this.inputEmail.value.toString().split("@")[0].charAt(0).toUpperCase() + this.inputEmail.value.toString().split("@")[0].slice(1)
        let header = {
            headers: {
                "Content-Type": "application/json",
            }
        }
        const data = {
            "name": name,
            "email": this.inputEmail.value,
            "password": this.inputPwd.value,
            "student_cnt" : this.props.pupilcount
             };
        document.body.style.cursor = 'progress';
        instanceAxios().post(CREATEUSER_URL, data, header)
            .then(response => {
                if (!(response.data.message==="Error")) {
                    console.log("CREATEUSER_URL", response.data, this.props.usersetup, response.data.user.id);
                    this.setState({newUser: response.data.user.id, newEmail: this.inputEmail.value})
                    this.setSetup(this.props.usersetup, response.data.user.id, response.data.user.class_id);
                }
                else {
                    console.log("CREATEUSER_URL_FAILED", Object.values(JSON.parse(JSON.stringify(response.data)).errortext)[0][0]); // , JSON.parse(response.data.errortext)
                    this.setState({
                        Error : Object.values(JSON.parse(JSON.stringify(response.data)).errortext)[0][0]
                    })
                    window.setTimeout(() => {
                        this.setState({
                            Error: ""
                        });
                    }, 2000);
                }
                document.body.style.cursor = 'default';
            })
            .catch (response => {
                console.log("CREATEUSER_URL_FAILED", response);
                document.body.style.cursor = 'default';
            })
    };

    setSetup=(usersetup, userID, classID)=>{
//        console.log("setSetup", usersetup);
//         this.changeState("curClass",usersetup.curClass, userID);
        this.changeState("class_id",classID, userID);
        this.changeState("classNumber",usersetup.classNumber, userID, classID);
        this.changeState("pupilCount",usersetup.pupilCount, userID, classID);
        this.changeState("currentYear",usersetup.currentYear, userID, classID);
        this.changeState("selectedSubj",usersetup.selectedSubj, userID, classID);
        this.changeState("subjCount",usersetup.subjCount, userID, classID);
        this.changeState("selectedSubjects",usersetup.selectedSubjects, userID, classID);
        this.changeState("markBlank",usersetup.markBlank, userID, classID);
        this.changeState("listnames",usersetup.titlekind, userID, classID);
        this.changeState("rangedays",usersetup.currentPeriodDateCount, userID, classID);
        this.changeState("rangedirection",usersetup.direction, userID, classID);
        this.changeState("withoutholidays",usersetup.withoutholidays, userID, classID);
    }

    changeState(name, value, userID, classID) {
        // let {curClass} = this.state
        let json, data;
        let {students : studs, curClass, subjects_list, selectedSubjects} = this.props.usersetup;
        console.log("changeState", name, value, userID)
        switch (name) {
            // case 'userId' : { this.setState({ userID : userID }); break;}
            case "class_id" :
                json = `{"class_id":${value}}`; break;
            case 'curClass' :
                json = `{"class_number":${value}}`; break;
            case 'classNumber' :
                json = `{"class_number":${value}}`; break;
            case 'pupilCount' :
                // if (value > pupilCount) {
                    //Заполним массив студентов (id, name, nick, rowno, class_id, user_id)
                    let arr = [];
                    for (let i = 0; i < value; i++) {
                        console.log("studs[i]", studs[i]); //JSON.parse(studs[i])
                        if (!(studs[i]) || ((typeof studs[i] === "object") && !(studs[i].hasOwnProperty('id'))))
                            arr.push({"id": 0, "student_name" : "", "student_nick" : numberToLang(i+1, ' ', 'rus'), "rowno" : i, "class_id": classID, "user_id" : userID});
                        else
                            arr.push({"id": studs[i].id, "student_name" : studs[i].student_name, "student_nick" : studs[i].student_nick, "rowno" : studs[i].rowno, "class_id": classID, "user_id" : userID})
                    }
                    json = `{"students":${JSON.stringify(arr)}}`;
                    data = JSON.parse(json);
                    console.log("PupilCountArr", arr, data);
                    this.props.onSetSetup(data, userID, curClass)
                // }
                json = `{"pupil_count":${value}}`; break;
            case 'currentYear' :
                // this.setState({
                //     currentYear: value,
                //     curYearDone : value?1:0
                // });
                json = `{"year_name":"${value.toString().replace(/[/]/g, '\\/')}"}`;
                // value&&this.props.onSetSetup(data, userID, curClass);
                break;
            case "selectedSubj" :
                console.log("selectedSubj", value);
                if (typeof value === "object") {
                    // let key1 = JSON.stringify(`"subj_key":"${value.subj_key}"`)
                    // let key2 = JSON.stringify(`"subj_name_ua":"${value.subj_name_ua}"`)
                    json = `{"selected_subject":"${value.subj_key},${value.subj_name_ua}"}`
                    // console.log(json, JSON.stringify(json))
                }
                else
                json = `{"selected_subject":"${value}"}`; break;
            case "subjCount" :
                console.log("selectedSubjsArray", selectedSubjects);
                json = `{"subjects_count":"${subjects_list.length+'/'+ selectedSubjects[0]===""?0:selectedSubjects.length}"}`; break;
            case "selectedSubjects" : // Количество выбранных для отслеживания оценок
                json = `{"selected_subjects":[${value.map(val=>`{"subj_key":"${val.subj_key}","subj_name_ua":"${val.subj_name_ua}"}`)}]}`;
                data = JSON.parse(json);
                console.log("selected_subjects", value, json);
                this.props.onSetSetup(data, userID, curClass);
                json = `{"subjects_count":"${subjects_list.length +'/'+ value.length}"}`; break;
            case "markBlank" :
                let   alias = "", pk = 0; //id = value;
                if (typeof value === "object") {
                    alias = value.alias;
                    pk = value.pk;
                    value = value.id;
                }
                else
                switch (value) {
                    case "markblank_twelve" : alias = "Двенадцатибальная"; pk = 1; break;
                    case "markblank_five" : alias = "Пятибальная"; pk = 2; break;
                    case "markblank_letters" : alias = "A-E/F"; pk = 3; break;
                    default: break;
                }
                let key1, key2, key3;
                json = `{"markblank_id":"${value}"}`; data = JSON.parse(json); key1 = data;
                // this.props.onSetSetup(data, this.props.userSetup.userID, this.props.userSetup.curClass)
                json = `{"markblank_alias":"${alias.toString().replace(/[/]/g, '\\/')}"}`; data = JSON.parse(json); key2 = data
                // this.props.onSetSetup(data, this.props.userSetup.userID, this.props.userSetup.curClass)
                json = `{"selected_marker":${pk}}`; data = JSON.parse(json); key3 = data;
                // this.props.onSetSetup(data, this.props.userSetup.userID, this.props.userSetup.curClass)
                json = `{"markblank":[${JSON.stringify(key1)},${JSON.stringify(key2)},${JSON.stringify(key3)}]}`; break;
            case "listnames" :
                json = `{"titlekind":"${value}"}`; break;
            case "rangedays" :
                console.log("rangedays", value)
                json = `{"perioddayscount":${value}}`; break;
            case "rangedirection" :
                console.log("DATA", data);
                json = `{"direction":"${value}"}`; break;
            case "withoutholidays" :
                document.body.style.cursor = 'default';
                json = `{"withoutholidays":${value}}`; break;
            default:
                break;
        }
        if (json) {
            data = JSON.parse(json);
            console.log(name, data);
            this.props.onSetSetup(data, userID, classID);
        }
    }

    // oAuth2Create() {
    //     const data = {
    //         // name: 'ClientName',
    //         // redirect: BASE_URL,
    //         "username": "test@gmail.com",
    //         "password": "test1",
    //         "grant_type": "password",
    //         "client_id": 2,
    //         "client_secret": "Z7ccv17TD6jf03E6MUTpFBXVl9NuLfzBKRqf8AFK",
    //         "scope": "*"
    //     };

        // axios.post(TOKEN_URL, data)
        //     .then(response => {
        //         console.log(response.data);
        //     })
        //     .catch (response => {
        //         console.log(response);
        //         // Список ошибок в отклике...
        //     })};

    componetDidMount() {
        this.inputEmail.propTypes = {
            emailAddress: emailPropType.isRequired, // can also specify emailPropType if it is not required
        };
    }
    hidePopup(){
        console.log("hidePopup")
        this.setState({
            Error : ""
        })
    }
    render() {

        return (
        <div className="loginSection">
            <div className="loginSubSection">
                <div><b>Зарегистрироваться:</b></div>
                <div>
                    <div className="inputBlockTop">
                        <div className="inputBlock">
                            <div><label>Email</label><input type="email" ref={input=>{this.inputEmail=input}}></input></div>
                            <div><label>Пароль</label><input type="password" ref={input=>{this.inputPwd=input}}></input></div>
                        </div>
                        <button onClick={this.createUser.bind(this)}>Сохранить</button>
                        <div className={this.state.Error.length?"popup3 show3":"popup3"} onClick={this.hidePopup.bind(this)}>
                            {this.state.Error.length?<span className="popuptext3" id="myPopup">{this.state.Error}</span>:""}
                        </div>
                    </div>
                    <div className="newUserHint">
                        {this.state.newUser?<div>Для начала работы проверьте письмо по адресу <b>{this.state.newEmail}</b>,
                            чтобы подтвердить электронный адрес</div>:""}
                    </div>
                    {/*<div className="inputBlock">*/}
                        {/*/!*<a href="{{ url('/auth/google') }}" class="btn btn-google"><i class="fa fa-google"></i> Google</a>*!/*/}
                        {/*<div><button>Google(Gmail)</button></div>*/}
                        {/*/!*<a href="{{ url('/auth/facebook') }}" class="btn btn-facebook"><i class="fa fa-facebook"></i> Facebook</a>*!/*/}
                        {/*<div><a href={FACEBOOK_URL}><button>FaceBook</button></a></div>*/}
                    {/*</div>*/}
                </div>
            </div>
            <div>
                <b>После регистрации появится возможность:</b>
                    <ol type="1">
                    <li>разослать приглашения для родителей и учеников класса</li>
                    <li>установить для учеников нужные имена или ники</li>
                    <li>следить за динамикой успеваемости</li>
                    <li>экспортировать и импортировать оценки из файла Excel</li>
                    <li>просматривать диаграммы успеваемости</li>
                    <li>отсылать родителям письма с оценками</li>
                    </ol>
            </div>
        </div>
    )
    }
}
const mapStateToProps = store => {
    // console.log(store) // посмотрим, что же у нас в store?
    return {
        user:       store.user,
        userSetup:  store.userSetup,
    }
}

const mapDispatchToProps = dispatch => {
    return ({
        onSetSetup: (data, userID, curClass) => {
            const asyncSetSetup = (data, userID, curClass) =>{
                return dispatch => {
                    // let responsedata = []
                    // dispatch({type: 'UPDATE_SETUP_LOCALLY', payload: data})
                    if (Object.keys(data)[0]==="class_number") {
                        let postdata = JSON.parse(`{"subjects_list":"${Object.values(data)[0]}"}`);
                        instanceAxios().get(SUBJECTS_GET_URL+'/'+Object.values(data)[0], postdata)
                            .then(response => {
                                // let responsedata = response.data;
                                // dispatch({type: 'UPDATE_SETUP_LOCALLY_SUBJLIST', payload: response.data})
                                let arr = response.data.map(value=>value.subj_key);

                                let postdata = `{"subjects_list":"${arr}"}`;

                                userID&&instanceAxios().post(UPDATESETUP_URL + '/' + userID, postdata)
                                    .then(response=>{
                                        console.log('UPDATE_SETUP_SUCCESSFULLY_subjects_list', response.data, userID);
                                    })
                                    .catch(response => {
                                        console.log('UPDATE_SETUP_FAILED_subjects_list', response);
                                    })
                                // let json = `{"subjects_count":"${response.data.length+"/0"}"}`;
                                // let postjson = JSON.parse(json);
                                // dispatch({type: 'UPDATE_SETUP_LOCALLY', payload: postjson});
                            })
                            .catch(response => {
                                console.log(response);
                                // dispatch({type: 'UPDATE_SETUP_FAILED', payload: response.data})
                                // Список ошибок в отклике...
                            })
                    }
                    if (userID) {
                        if (Object.keys(data)[0]==="selected_subjects") {
                            console.log("SELECTED_SUBJECTS", data, Object.values(data)[0], Object.values(data)[0].map(val=>val.subj_key), Object.values(data)[0].map(val=>val.subj_key).join())
                            let json = `{"selected_subjects":"${Object.values(data)[0].map(val=>val.subj_key).join()}"}`;
                            data = JSON.parse(json);
                        }
                        if (Object.keys(data)[0]==="students") {
                            console.log("STUDENTS_GET_URL", userID, curClass, data, JSON.stringify(data))
                            instanceAxios().post(STUDENTS_GET_URL + '/' + userID + '/class/' + curClass, JSON.stringify(data))
                                .then(response => {
                                    console.log('UPDATE_STUDENTS_REMOTE', response.data)
                                    // dispatch({type: 'UPDATE_STUDENTS_REMOTE', payload: response.data})
                                })
                                .catch(response => {
                                    console.log(response);
                                    // dispatch({type: 'UPDATE_STUDENTS_FAILED', payload: response.data})
                                })
                        }
                        else {
                            console.log("UPDATESETUP_URL", userID, curClass, data, JSON.stringify(data))
                            instanceAxios().post(UPDATESETUP_URL + '/' + userID, data)
                                .then(response => {
                                    // dispatch({type: 'UPDATE_SETUP_REMOTE', payload: response.data})
                                })
                                .catch(response => {
                                    console.log(response);
                                    // dispatch({type: 'UPDATE_SETUP_FAILED', payload: response.data})
                                })
                        }
                    }
                }
            }
            dispatch(asyncSetSetup(data, userID, curClass))
        },
    })
}
// export default LoginBlock
export default connect(mapStateToProps, mapDispatchToProps)(LoginBlock)


