/**
 * Created by Paul on 07.04.2019.
 */
import React, { Component } from 'react'
import { connect } from 'react-redux'
import { InputForEdit } from '../InputForEdit/inputforedit'
import AddSubject from '../AddSubject/addsubject'
import './emaillist.css'
import { EMAIL_ADD_URL, EMAIL_GET_URL, EMAIL_DELETE_URL, instanceAxios } from '../../config/URLs'

class EmailList extends Component {
    constructor(props){
        super(props);
        this.state = {
            addEmail : false,
            emails : [],
        }
    }
    componentWillMount(){
        instanceAxios().get(EMAIL_GET_URL + '/' + this.props.userID + '/emails', [])
            .then(response => {
                console.log(response.data)
                this.setState({
                    emails : response.data
                })
            })
            .catch(response => {
                console.log(response);
            })
    }
    addEmailShow(){
        this.setState({addEmail:true})
    }
    addEmail(email){
        console.log(email)
        instanceAxios().get(EMAIL_ADD_URL + '/' + this.props.userID + '/email/' + email, [])
            .then(response => {
                console.log(response.data, this.state.emails)
                let emails = this.state.emails
                emails.push(response.data)
                this.setState({
                    // emails : this.state.emails.push(`<div className="itemInEmailList" key=${response.data.id}>${response.data.email}<button id=${response.data.id} onClick=${this.deleteItemInList.bind(this)}>-</button></div>`)
                    emails : emails
                })
                // dispatch({type: 'UPDATE_SETUP_REMOTE', payload: response.data})
                // this.props.onInitState(response.data.subjects_list, response.data.subjects_count);
            })
            .catch(response => {
                console.log(response);
            })
     }
    deleteItemInList(e){
        console.log(e, e.target.id)
        let id = e.target.id
        instanceAxios().get(EMAIL_DELETE_URL + '/' + this.props.userID + '/emaildelete/' + id, [])
            .then(response => {
                console.log(response.data, id)

                let emails = this.state.emails
                emails = emails.filter((item)=>(!(item.id.toString()===id.toString())))
                this.setState({
                    emails : emails
                })

                // dispatch({type: 'UPDATE_SETUP_REMOTE', payload: response.data})
                // this.props.onInitState(response.data.subjects_list, response.data.subjects_count);
            })
            .catch(response => {
                console.log(response);
            })
        // let emails = this.state.emails
        // emails = emails.filter((item)=>(!(item.id===e.target.id)))
        // this.setState({
        //     emails : emails
        // })
        // alert("Удалить почту?")
    }
    hideAddEmail=()=> {
        this.setState({addEmail: false})
    }
    render(){
        console.log(this.state.emails)
        let emails = this.state.emails.map((item, i) => (<div className="itemInEmailList" key={item.id}>{item.email}<button id={item.id} onClick={this.deleteItemInList.bind(this)}>-</button></div>))
        return (
            <div className="emailList">
                <div className = "emailListHeader">
                <div>Адреса рассылки</div><button className="emaiListAddButton" onClick={this.addEmailShow.bind(this)}>+</button>
                {this.state.addEmail&&<AddSubject title={"Новый email"} firehide={this.hideAddEmail.bind(this)} addfunc={this.addEmail.bind(this)}/>}
                <div>{this.props.studentName}</div>
                </div>
                <div className="emailListItems">
                    <div className="defaultItemInEmailList">{this.props.user.email}</div>
                    {emails}
                    {/*<div className="itemInEmailList">test33@gmail.com<button onClick={this.deleteItemInList.bind(this)}>-</button></div>*/}
                    {/*<div className="itemInEmailList">test44@gmail.com<button onClick={this.deleteItemInList.bind(this)}>-</button></div>*/}
                </div>
            </div>
        )
    }
}

// приклеиваем данные из store
const mapStateToProps = store => {
    // console.log(store) // посмотрим, что же у нас в store?
    return {
        user:       store.user,
        userSetup:  store.userSetup,
    }
}
const mapDispatchToProps = dispatch => {
    return ({
        // onInitState: () => dispatch([]),
        // onUserLoggingOut  : token => dispatch(userLoggedOut(token)),
    })
}
export default connect(mapStateToProps, mapDispatchToProps)(EmailList)