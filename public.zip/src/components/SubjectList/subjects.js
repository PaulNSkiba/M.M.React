/**
 * Created by Paul on 11.01.2019.
 */
var subjects = [

    {id:'#algebr', name:	'Алгебра'},
    {id:'#lngeng', name:	'Англійська мова'},
    {id:'#biolog', name:	'Біологія'},
    {id:'#htrwld', name:	'Всесвітня історія'},
    {id:'#geogph', name:	'Географія'},
    {id:'#groedu', name:	'Громад. освіта'},
    {id:'#ecolog', name:	'Екологія'},
    {id:'#econom', name:	'Економіка'},
    {id:'#forltr', name:	'Зар. література'},
    {id:'#zahyst', name:	'ЗВ/МСП'},
    {id:'#inform', name:	'Інформатика'},
    {id:'#htrold', name:	'Історія ст. світу'},
    {id:'#logics', name:	'Логіка'},
    {id:'#mathem', name:	'Математика'},
    {id:'#arts__', name:	'Мистецтво'},
    {id:'#musart', name:	'Музичне мистецтво'},
    {id:'#hltbas', name:	'Основи здоров\'я'},
    {id:'#lawbas', name:	'Правознавство'},
    {id:'#naturl', name:	'Природознавство'},
    {id:'#techno', name:	'Технології'},
    {id:'#workng', name:	'Трудове навчання'},
    {id:'#ltrukr', name:	'Укр. література'},
    {id:'#lngukr', name:	'Українська мова'},
    {id:'#phythc', name:	'Фізика'},
    {id:'#phithc', name:	'Фізкультура'},
    {id:'#chemic', name:	'Хімія'},
    {id:'#xxxxxx', name:	'Інші(Створити)...'},

]
export default function subjects() { return subjects};