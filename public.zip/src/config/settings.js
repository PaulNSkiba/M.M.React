/**
 * Created by Paul on 21.01.2019.
 */
// Personal access client created successfully.
//     Client ID: 1
// Client secret: 3q8EWhboZonwIdfYTRFjHKKygciMh4tYlpc0Ukal
// Password grant client created successfully.
//     Client ID: 2
// Client secret: Z7ccv17TD6jf03E6MUTpFBXVl9NuLfzBKRqf8AFK
import { store } from '../store/configureStore'

export const OAUTH_CLIENT_ID = 2
export const OAUTH_CLIENT_SECRECT = 'Z7ccv17TD6jf03E6MUTpFBXVl9NuLfzBKRqf8AFK'