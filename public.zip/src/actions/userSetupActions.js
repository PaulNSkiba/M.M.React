/**
 * Created by Paul on 20.01.2019.
 */
// export function setCurClass(curClass, SubjCount) {
//     return {
//         type: 'SET_CLASS',
//         payload: [curClass, SubjCount],
//     }
// }

export function initState() {
    return {
        type: 'INIT_STATE',
        payload: [],
    }
}